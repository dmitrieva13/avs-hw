#include "twodim.h"
#include <iostream>

TwoDim::TwoDim() {
	size=0;
}

TwoDim::TwoDim(int size, int* inputArr) {
	this->size=size;
	this->arr=inputArr;
}

void TwoDim::In(FILE* fin) {
	fscanf(fin, "%d", &size);
	arr=new int[size*size] {};
	for (int i=0;i<size*size;++i) {
		fscanf(fin, "%d", &arr[i]);
	}
}

void TwoDim::RandomIn() {
	size=1+Random()%20;
	arr=new int[size*size];
	for (int i=0;i<size*size;++i) {
		arr[i]=Random();
	}
}

void TwoDim::Output(FILE* fout) {
	fprintf(fout, "This is two-dimensional matrix with size %d\n", size);
	for (int i=0;i<size*size;++i) {
		fprintf(fout, "%d ", arr[i]);
		if ((i+1)%size==0) {
			fprintf(fout,"\n");
		}
	}
	fprintf(fout, "Average = %f\n\n", this->Average());
}

double TwoDim::Average() {
	int count=size*size;
	double sum=0.0;
	for (int i=0;i<count;++i) {
		sum+=arr[i];
	}
	double res=1.0*sum/count;
	return res;
}

TwoDim::~TwoDim() {
	size=0;
	delete[] arr;
	arr=nullptr;
}
