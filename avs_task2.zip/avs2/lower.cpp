#include "lower.h"
#include <iostream>

Lower::Lower() {
	size=0;
	arr=new int[0];
}

Lower::Lower(int size, int* inputArr) {
	this->size=size;
	this->arr=inputArr;
}

void Lower::In(FILE* fin) {
	fscanf(fin, "%d", &size);
	int len=(size+1)*(size/2)+(1+size/2)*(size%2);
	arr=new int[len] {};
	for (int i=0;i<len;++i) {
		fscanf(fin, "%d", &arr[i]);
	}
}

void Lower::RandomIn() {
	size=1+Random()%20;
	int len=(size+1)*(size/2)+(1+size/2)*(size%2);
	arr=new int[len];
	for (int i=0;i<len;++i) {
		arr[i]=Random();
	}
}

void Lower::Output(FILE* fout) {
	fprintf(fout, "This is lower-triangle matrix with size %d\n", size);
	int current=0;
	for (int i=0;i<size;++i) {
		for (int j=0;j<size;++j) {
			if (i>=j) {
				fprintf(fout,"%d ",arr[current]);
				++current;
			} else {
				fprintf(fout,"%d ",0);
			}
		}
		fprintf(fout,"\n");
	}
	fprintf(fout, "Average = %f\n\n", this->Average());
}

double Lower::Average() {
	int count=size*size;
	int len=(size+1)*(size/2)+(1+size/2)*(size%2);
	double sum=0.0;
	for (int i=0;i<len;++i) {
		sum+=arr[i];
	}
	double res=1.0*sum/count;
	return res;
}

Lower::~Lower() {
	size=0;
	delete[] arr;
	arr=nullptr;
}
