#ifndef TWODIM_H
#define TWODIM_H

#include "matrix.h"

// Class of two-dimensional matrix.
class TwoDim: public Matrix {
	public:
		TwoDim();
		TwoDim(int size, int* arr);
		virtual void In(FILE* fin);
		virtual void RandomIn();
		void Output(FILE* fout);
		double Average();
		~TwoDim();
};

#endif
