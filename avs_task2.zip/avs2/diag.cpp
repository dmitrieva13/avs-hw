#include "diag.h"
#include <iostream>

Diagonal::Diagonal() {
	size=0;
	arr=new int[0];
}

Diagonal::Diagonal(int size, int* inputArr) {
	this->size=size;
	this->arr=inputArr;
}

void Diagonal::In(FILE* fin) {
	fscanf(fin, "%d", &size);
	arr=new int[size] {};
	for (int i=0;i<size;++i) {
		fscanf(fin, "%d", &arr[i]);
	}
}

void Diagonal::RandomIn() {
	size=1+Random()%20;
	arr=new int[size];
	for (int i=0;i<size;++i) {
		arr[i]=Random();
	}
}

void Diagonal::Output(FILE* fout) {
	fprintf(fout, "This is diagonal matrix with size %d\n", size);
	for (int i=0;i<size;++i) {
		for (int j=0;j<size;++j) {
			if (i==j) {
				fprintf(fout, "%d ", arr[i]);
			} else {
				fprintf(fout,"%d ",0);
			}
		}
		fprintf(fout,"\n");
	}
	fprintf(fout, "Average = %f\n\n", this->Average());
}

double Diagonal::Average() {
	int count=size*size;
	double sum=0.0;
	for (int i=0;i<size;++i) {
		sum+=arr[i];
	}
	double res=1.0*sum/count;
	return res;
}

Diagonal::~Diagonal() {
	size=0;
	delete[] arr;
	arr=nullptr;
}
