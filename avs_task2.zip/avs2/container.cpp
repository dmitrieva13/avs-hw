#include <iostream>
#include "container.h"

Container::Container() {
	length=0;
	cont=new Matrix*[maxLen];
}

Container::Container(int len) {
	length=len;
	cont=new Matrix*[length];
}

void Container::In(FILE* fin) {
	int type;
	while (fscanf(fin,"%d ",&type)!=EOF) {
		switch (type) {
			case 1:
				cont[length]=new TwoDim();
				cont[length]->In(fin);
				++length;
				break;
			case 2:
				cont[length]=new Diagonal();
				cont[length]->In(fin);
				++length;
				break;
			case 3:
				cont[length]=new Lower();
				cont[length]->In(fin);
				++length;
				break;
			default:
				cout<<"incorrect type!\n";
				return;
		}	
	}
}

void Container::RandomIn(int count) {
	for (int i=0;i<count;++i) {
		int key=Random()%3+1;
		switch (key) {
			case 1:
				cont[length]=new TwoDim();
				cont[length]->RandomIn();
				++length;
				break;
			case 2:
				cont[length]=new Diagonal();
				cont[length]->RandomIn();
				++length;
				break;
			case 3:
				cont[length]=new Lower();
				cont[length]->RandomIn();
				++length;
				break;
			default:
				cout<<"incorrect type!\n";
				return;
		}
	}
}

void Container::Output(FILE* fout) {
	fprintf(fout, "Container contains %d matrices\n",length);
	for (int i=0;i<length;++i) {
		cont[i]->Output(fout);
	}
}

void Container::Sort(FILE* fout) {
	int i,j,top,bottom,mid,hop;
	Matrix* temp;
	for (i=1;i<length;++i) {
		temp=cont[i];
		top=i;
		bottom=0;
		hop=1;
		do {
			mid=top-hop;
			hop<<=1;
			if (temp->Average()<(cont[mid])->Average()) {
				top=mid;
			} else {
				bottom=mid+1;
			}
		} while (bottom+hop<=top);

		while (bottom!=top) {
			mid=(top+bottom)/2;
			if (temp->Average()<(cont[mid])->Average()) {
				top=mid;
			} else {
				bottom=mid+1;
			}
		}
		for (j=i;j>bottom;--j) {
			cont[j]=cont[j-1];
		}
		cont[j]=temp;
	}
	Output(fout);
}

Container::~Container() {
	for (int i=0;i<length;++i) {
		delete cont[i];
	}
	length=0;
	delete[] cont;
	cont=nullptr;
}
