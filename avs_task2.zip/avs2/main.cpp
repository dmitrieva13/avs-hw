#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include "container.h"

using namespace std;

void errMessage1() {
	cout << "incorret command line!\n Waited:\n    command -f infile outfile\n Or:\n    command -n number outfile\n";
}

void errMessage2() {
	cout << "incorret qualifier line!\n Waited:\n    command -f infile outfile\n Or:\n    command -n number outfile\n";
}

void errMessage3() {
	cout<<"incorrect input: no such file!\n";
}

int main(int argc, char* argv[]) {
	// Check if the number of arguments is correct.
	if (argc!=4) {
		errMessage1();
		return 1;
	}
	cout << "Start\n";
	Container c=Container();
	if (strcmp(argv[1],"-f")==0) {
		FILE* fin;
			fin=fopen(argv[2],"r+");
			if (fin==nullptr) {
				errMessage3();
				return 3;
			}
			c.In(fin);
			fclose(fin);
	} else if (strcmp(argv[1],"-n")==0) {
		auto size=stoi(argv[2]);
		if ((size<1) || (size>1000)) {
			cout<<"Incorrect number of matrices: it must be from 1 to 1000!\n";
		return 4;
		}
		c.RandomIn(size);
	} else {
		errMessage2();
		return 2;
	}

	FILE* fout;
	fout=fopen(argv[3],"w");
	fprintf(fout,"Filled container:\n");
	c.Output(fout);

	fprintf(fout,"\nSorted container:\n");
	c.Sort(fout);
	fclose(fout);

	cout<<"Stop\n";
	return 0;
}
