#ifndef MATRIX_H
#define MATRIX_H

#include "rnd.h"
#include <cstdio>

// Base class of matrix.
class Matrix {
	public:
		Matrix() {};
		Matrix(int size, int* arr) {};
		// Fill matrix with data from file.
		virtual void In(FILE* fin) {};
		// Fill matrix with random data.
		virtual void RandomIn() {};
		// Output info about matrix.
		virtual void Output(FILE* fout) {};
		// Count average number for matrix.
		virtual double Average() {return 0.0;};
		~Matrix() {};

	protected:
		int size;
		int* arr;
};

#endif
