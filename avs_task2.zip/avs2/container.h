#ifndef CONTAINER_H
#define CONTAINER_H

#include "twodim.h"
#include "lower.h"
#include "diag.h"

class Container {
	public:
		Container();
		Container(int len);
		// Fill a container from file.
		void In(FILE* fin);
		// Fill a container with random data.
		void RandomIn(int count);
		// Output matrices from container.
		void Output(FILE* fout);
		// Sort matrices with binary search.
		void Sort(FILE* fout);
		~Container();

	private:
		enum {maxLen=1000};
		int length;
		Matrix** cont;


};

#endif
