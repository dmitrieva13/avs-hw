#ifndef LOWER_H
#define LOWER_H

#include "matrix.h"

// Class of lower-triangle matrix.
class Lower: public Matrix {
	public:
		Lower();
		Lower(int size, int* arr);
		virtual void In(FILE* fin);
		virtual void RandomIn();
		void Output(FILE* fout);
		double Average();
		~Lower();
};

#endif
