#ifndef DIAGONAL_H
#define DIAGONAL_H

#include "matrix.h"

// Class of diagonal matrix.
class Diagonal: public Matrix {
	public:
		Diagonal();
		Diagonal(int size, int* arr);
		virtual void In(FILE* fin);
		virtual void RandomIn();
		void Output(FILE* fout);
		double Average();
		~Diagonal();
};

#endif
