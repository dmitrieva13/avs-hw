from extender import *

# Reading container from file.
def ReadStrArray(container,strArray):
    arrLen=len(strArray)
    i=0
    matrixNum=0
    while i<arrLen:
        line=strArray[i]
        key=int(line)
        if key==1:
            i+=1
            matrix=TwoDim()
            i=matrix.ReadStrArray(strArray,i)
        elif key==2:
            i+=1
            matrix=Diagonal()
            i=matrix.ReadStrArray(strArray,i)
        elif key==3:
            i+=1
            matrix=Lower()
            i=matrix.ReadStrArray(strArray,i)
        else:
            return matrixNum
        if i==0:
            return matrixNum
        matrixNum+=1
        container.store.append(matrix)
    return matrixNum
