from matrix import *
import random

# Class of two-dimensional matrices.
class TwoDim(Matrix):
    def __init__(self):
        self.size=0
        self.arr=[]

    # Reading matrix from file.
    def ReadStrArray(self, strArray, i):
        if i>=len(strArray)-1:
            return 0
        self.size=int(strArray[i])
        if i+1>len(strArray)-self.size*self.size:
            return 0
        for j in range(0,self.size*self.size):
            self.arr.append(int(strArray[i+j+1]))
        i+=(1+self.size*self.size)
        return i

    # Creating random matrix.
    def RandomInput(self):
        self.size=random.randint(1,20)
        for i in range(0,self.size*self.size):
            self.arr.append(random.randint(-1000,10000))
        pass

    # Printing matrix to console.
    def Print(self):
        print("Two-dimensional matrix with size "+str(self.size))
        line=""
        for i in range(0,self.size*self.size):
            line+=str(self.arr[i])+" "
            if (i+1)%self.size==0:
                print(line)
                line=""
        print("Average = "+str(self.Average())+"\n")
        pass

    # Printing matrix to file.
    def Output(self,ostream):
        ostream.write("Two-dimensional matrix with size "+str(self.size)+"\n")
        line=""
        for i in range(0,self.size*self.size):
            line+=str(self.arr[i])+" "
            if (i+1)%self.size==0:
                ostream.write(line+"\n")
                line=""
        ostream.write("Average = "+str(self.Average())+"\n")
        pass

    # Count average of two-dimensional matrix.
    def Average(self):
        count=self.size*self.size
        summa=0
        for i in range(0,self.size*self.size):
            summa+=self.arr[i-1]
        result=1.0*summa/count
        return result
