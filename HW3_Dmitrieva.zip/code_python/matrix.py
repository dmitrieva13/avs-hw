# Basic class of matrices.
class Matrix:
    def ReadStrArray(self, strArray, i):
        pass

    def RandomInput(self):
        pass

    def Print(self):
        pass

    def Output(self, ostream):
        pass

    def Average(self):
        pass
