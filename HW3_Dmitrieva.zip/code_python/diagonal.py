from matrix import *
import random

# Class of diagonal matrices.
class Diagonal(Matrix):
    def __init__(self):
        self.size=0
        self.arr=[]

    # Reading diagonal matrix from file.
    def ReadStrArray(self, strArray, i):
        if i>=len(strArray)-1:
            return 0
        self.size=int(strArray[i])
        if i+1>len(strArray)-self.size:
            return 0
        for j in range(0,self.size):
            self.arr.append(int(strArray[i+j]))
        i+=(1+self.size)
        return i

    # Creating random diagpnal matrix.
    def RandomInput(self):
        self.size=random.randint(1,20)
        for i in range(0,self.size):
            self.arr.append(random.randint(-1000,10000))
        pass

    # Print matrix to console.
    def Print(self):
        print("Diagonal matrix with size "+str(self.size))
        for i in range(0,self.size):
            line=""
            for j in range (0,self.size):
                if i==j:
                    line+=str(self.arr[i])+" "
                else:
                    line+="0 "
            print(line)
        print("Average = "+str(self.Average())+"\n")
        pass

    # Print matrix to file.
    def Output(self,ostream):
        ostream.write("Diagonal matrix with size "+str(self.size)+"\n")
        for i in range(0,self.size):
            line=""
            for j in range (0,self.size):
                if i==j:
                    line+=str(self.arr[i])+" "
                else:
                    line+="0 "
            ostream.write(line+"\n")
        ostream.write("Average = "+str(self.Average())+"\n")
        pass

    # Count average of diagonal matrix.
    def Average(self):
        count=self.size*self.size
        summa=0
        for i in range(0,self.size):
            summa+=self.arr[i]
        result=1.0*summa/count
        return result


