# Class of container which contains matrices.
class Container:
    def __init__(self):
        self.store=[]

    # Print container to console.
    def Print(self):
        print("This container has "+str(len(self.store))+" matrices:")
        for matrix in self.store:
            matrix.Print()
        pass

    # Print container to file.
    def Output(self,ostream):
        ostream.write("This container has "+str(len(self.store))+" matrices:\n")
        for matrix in self.store:
            matrix.Output(ostream)
            ostream.write("\n")
        pass

    # Sorting matrices in container.
    def Sort(self):
        for i in range (1,len(self.store)):
            temp=self.store[i]
            top=i
            bottom=0
            hop=1
            while True:
                mid=top-hop
                hop<<=1
                if temp.Average()<self.store[mid].Average():
                    top=mid
                else:
                    bottom=mid+1
                if bottom+hop>top:
                    break
            while bottom!=top:
                mid=(top+bottom)/2
                if temp.Average()<self.store[mid].Average():
                    top=mid
                else:
                    bottom=mid+1
            j=i
            for index in range(i,bottom,-1):
                self.store[index]=self.store[index-1]
                j=index-1
            self.store[j]=temp
        pass
