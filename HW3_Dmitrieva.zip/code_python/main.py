import sys
import string

from extender import *

if __name__ == '__main__':
    # Checking if there's not enough arguments.
    if len(sys.argv)<=2:
        print("Incorrect command line! Expected:\n\tpython main -f <input file> [<output file>]\nOr:\n\tpython main -n <matrices number> [<output file>]")
        exit()
    elif len(sys.argv)==4:
        option=sys.argv[1]
        if option=='-f':
            inputFileName=sys.argv[2]
            outputFileName=sys.argv[3]
        elif option=='-n':
            number=int(sys.argv[2])
            outputFileName=sys.argv[3]
        else:
            print("Incorrect command line! Expected:\n\tpython main -f <input file> [<output file>]\nOr:\n\tpython main -n <matrices number> [<output file>]")
            exit()
    elif len(sys.argv)==3:
        outputFileName="output.txt"
        option=sys.argv[1]
        if option=='-f':
            inputFileName=sys.argv[2]
        elif option=='-n':
            number=int(sys.argv[2])
        else:
            print("Incorrect command line! Expected:\n\tpython main -f <input file> [<output file>]\nOr:\n\tpython main -n <matrices number> [<output file>]")
            exit()
    # Checking if there's too many arguments.
    else:
        print("Incorrect command line! Expected:\n\tpython main -f <input file> [<output file>]\nOr:\n\tpython main -n <matrices number> [<output file>]")
        exit()
    
    print("=> Start")
    container=Container()
    if option=='-f':
        ifile=open(inputFileName)
        info=ifile.read()
        ifile.close()
        strArray=info.replace('\n',' ').split(' ')
        while '' in strArray:
            strArray.remove('')
        matrixNum=ReadStrArray(container,strArray)
    elif option=='-n':
        if number<=0 or number>1000:
            print("Incorrect imput: number of matrices must be from 1 to 1000!")
            exit()
        RandomInput(container,number)
    container.Print()
    ofile=open(outputFileName,'w')
    container.Output(ofile)
    # Sorting container.
    container.Sort()
    # Print sorted container.
    print("Sorted container:")
    container.Print()
    # Output sorted container to file.
    ofile.write("\tSorted container:\n")
    container.Output(ofile)
    ofile.close()
    print("=> Finish")
