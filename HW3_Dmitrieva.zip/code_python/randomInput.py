from extender import *
import random

# Filling container with random matrices.
def RandomInput(container,n):
    for i in range(n):
        key=random.randint(1,3)
        if key==1:
            matrix=TwoDim()
            matrix.RandomInput()
            container.store.append(matrix)
        elif key==2:
            matrix=Diagonal()
            matrix.RandomInput()
            container.store.append(matrix)
        elif key==3:
            matrix=Lower()
            matrix.RandomInput()
            container.store.append(matrix)
    pass
