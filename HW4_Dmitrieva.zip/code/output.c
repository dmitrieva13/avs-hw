#include <stdio.h>
#include "extdata.h"

double MatrixAverage(void *m, int length,int size);

int OutTwoDim(void *td,FILE *ofst) {
	fprintf(ofst,"This is two-dimensional matrix with size %d\n",*((int*)td));
	int size=*((int*)td);
	for (int i=0;i<size*size;++i) {
		fprintf(ofst,"%d ",*((int*)(td+intSize*(i+1))));
		if ((i+1)%size==0)
			fprintf(ofst,"\n");
	}
	double a=MatrixAverage(td+intSize,size*size,size*size);
	fprintf(ofst,"Average = %f\n\n",a);
	return size*size+1;
}

int OutDiagonal(void *d,FILE *ofst) {
	int size=*((int*)d);
	fprintf(ofst,"This is diagonal matrix with size %d\n",size);
	for (int i=0;i<size;++i) {
		for (int j=0;j<size;++j) {
			if (i==j) {
				fprintf(ofst,"%d ",*((int*)(d+intSize*(i+1))));
			} else {
				fprintf(ofst,"0 ");
			}
		}
		fprintf(ofst,"\n");
	}
	double a=MatrixAverage((d+intSize),size,size*size);
	fprintf(ofst,"Average = %f\n\n",a);
	return size+1;
}

int OutLower(void *l,FILE *ofst) {
	fprintf(ofst,"This is lower-triangle matrix with size %d\n",*((int*)l));
	int size=*((int*)l);
	int length=(size+1)*(size/2)+(1+size/2)*(size%2);
	int count=0;
	for (int i=0;i<size;++i) {
		for (int j=0;j<size;++j) {
			if (i>=j) {
				fprintf(ofst,"%d ",*((int*)(l+intSize*(count+1))));
				++count;
			} else {
				fprintf(ofst,"0 ");
			}
		}
		fprintf(ofst,"\n");
	}
	double a=MatrixAverage((l+intSize),length,size*size);
	fprintf(ofst,"Average = %f\n\n",a);
	return length+1;
}

int OutMatrix(void *m,FILE *ofst) {
	void *tmp=m;
	int key=*((int*)tmp);
	if (key==TWODIM) {
		int size=OutTwoDim(m+intSize,ofst);
		return size+1;
	} else if (key==DIAGONAL) {
		int size=OutDiagonal(m+intSize,ofst);
		return size+1;
	} else if (key==LOWER) {
		int size=OutLower(m+intSize,ofst);
		return size+1;
	} else {
		return 0;
	}
}

void OutContainer(void *c,int len,FILE *ofst) {
	void *tmp=c;
	fprintf(ofst,"Container contains %d matrices.\n\n",len);
	for (int i=0;i<len;++i) {
		fprintf(ofst,"%d: ",i+1);
		int size=OutMatrix(tmp,ofst);
		tmp=tmp+size*intSize;
	}
}


int ConsoleOutTwoDim(void *td) {
	printf("This is two-dimensional matrix with size %d\n",*((int*)td));
	int size=*((int*)td);
	for (int i=0;i<size*size;++i) {
		printf("%d ",*((int*)(td+intSize*(i+1))));
		if ((i+1)%size==0)
			printf("\n");
	}
	double a=MatrixAverage(td+intSize,size*size,size*size);
	printf("Average = %f\n\n",a);
	return size*size+1;
}

int ConsoleOutDiagonal(void *d) {
	int size=*((int*)d);
	printf("This is diagonal matrix with size %d\n",size);
	for (int i=0;i<size;++i) {
		for (int j=0;j<size;++j) {
			if (i==j) {
				printf("%d ",*((int*)(d+intSize*(i+1))));
			} else {
				printf("0 ");
			}
		}
		printf("\n");
	}
	double a=MatrixAverage((d+intSize),size,size*size);
	printf("Average = %f\n\n",a);
	return size+1;
}

int ConsoleOutLower(void *l) {
	printf("This is lower-triangle matrix with size %d\n",*((int*)l));
	int size=*((int*)l);
	int length=(size+1)*(size/2)+(1+size/2)*(size%2);
	int count=0;
	for (int i=0;i<size;++i) {
		for (int j=0;j<size;++j) {
			if (i>=j) {
				printf("%d ",*((int*)(l+intSize*(count+1))));
				++count;
			} else {
				printf("0 ");
			}
		}
		printf("\n");
	}
	double a=MatrixAverage((l+intSize),length,size*size);
	printf("Average = %f\n\n",a);
	return length+1;
}

int ConsoleOutMatrix(void *m) {
	void *tmp=m;
	int key=*((int*)tmp);
	if (key==TWODIM) {
		int size=ConsoleOutTwoDim(m+intSize);
		return size+1;
	} else if (key==DIAGONAL) {
		int size=ConsoleOutDiagonal(m+intSize);
		return size+1;
	} else if (key==LOWER) {
		int size=ConsoleOutLower(m+intSize);
		return size+1;
	} else {
		return 0;
	}
}


void ConsoleOutContainer(void *c,int len) {
	void *tmp=c;
	printf("Container contains %d matrices.\n\n",len);
	for (int i=0;i<len;++i) {
		printf("%d: ",i+1);
		int size=ConsoleOutMatrix(tmp);
		tmp=tmp+size*intSize;
	}
}

