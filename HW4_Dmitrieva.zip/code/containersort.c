#include <stdio.h>
#include "extdata.h"

int OutMatrix(void *m,FILE *ofst);
int ConsoleOutMatrix(void *m);

void Sort(void *cont, int len, FILE *ofst) {
	int i,j,top,bottom,mid,hop;
	void* temp;
	void *c=cont;
	int indexes[len];
	for (int i=0;i<len;++i)
		indexes[i]=i;
	int msizes[len];
	for (int i=0;i<len;++i) {
		int size=1+getSize(c);
		msizes[i]=size;
		c=c+size*intSize;
	}
	int count=getSize(cont);
	double averages[len];
	c=cont;
	for (int i=0;i<len;++i) {
		int key=*((int*)c);
		int size=*((int*)(c+intSize));
		int length=0;
		if (key==1)
			length=size*size;
		else if (key==2)
			length=size;
		else if (key==3)
			length=(size+1)*(size/2)+(1+size/2)*(size%2);
		averages[i]=MatrixAverage(c+intSize*2,length,size*size);
		c=c+intSize*msizes[i];
	}
	for (i=1;i<len;++i) {
		double current=averages[i];
		int currindex=indexes[i];
		top=i;
		bottom=0;
		hop=1;
		do {
			mid=top-hop;
			hop<<=1;
			if (current<averages[mid]) {
				top=mid;
			} else {
				bottom=mid+1;
			}
		} while (bottom+hop<=top);
		while (bottom!=top) {
			mid=(top+bottom)/2;
			if (current<averages[mid]) {
				top=mid;
			} else {
				bottom=mid+1;
			}
		}
		for (j=i;j>bottom;--j) {
			averages[j]=averages[j-1];
			indexes[j]=indexes[j-1];
		}
		averages[j]=current;
		indexes[j]=currindex;
		}
		for (int i=0;i<len;++i) {
			int index=indexes[i];
			void *add=cont;
			for (int j=0;j<index;++j) {
				add=add+intSize*msizes[j];
			}
			OutMatrix(add,ofst);
			ConsoleOutMatrix(add);
		}
}

