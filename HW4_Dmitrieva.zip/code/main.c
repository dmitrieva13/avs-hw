#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"

void errMessage1() {
	printf("incorrect command line!\n Expected:\n\tcommand -f <infile> <outfile>\n Or:\n\tcommand -n <number> <outfile>\n");
}

void errMessage2() {
	printf("incorrect qualifier value!\n Expected:\n\tcommand -f <infile> <outfile>\n Or:\n\tcommand -n <number> <outfile>\n");
}

int main(int argc,char* argv[]) {
	unsigned char cont[maxSize];
	int len=0;
	if (argc!=4) {
		errMessage1();
		return 1;
	}
	printf("=> Start\n");
	if (strcmp(argv[1],"-f")==0) {
		FILE *ifst=fopen(argv[2],"r");
		InContainer(cont,&len,ifst);
	} else if (strcmp(argv[1],"-n")==0) {
		int size=atoi(argv[2]);
		if ((size<1)||(size>1000)) {
			printf("incorrect number of matrices! expected number from 1 to 1000\n");
			return 3;
		}
		InRndContainer(cont,&len,size);
	} else {
		errMessage2();
		return 2;
	}
	FILE *ofst=fopen(argv[3],"w");
	OutContainer(cont,len,ofst);
	fprintf(ofst,"\tSorted container:\n");
	printf("\tSorted container:\n");
	Sort(cont,len,ofst);
	fclose(ofst);
	printf("=> Finish\n");
	return 0;
}
