#ifndef __extdata__
#define __extdata__

extern int const intSize;
extern int const maxSize;
extern int const TWODIM;
extern int const DIAGONAL;
extern int const LOWER;

extern double MatrixAverage(void *m, int length,int size);
int getSize(void *m);
void Sort(void *cont,int len, FILE *ofst);

double LowerAverage(void *l, int len, int size);

double DiagonalAverage(void *d, int len,int size);

double TwoDimAverage(void *td, int len,int size);
void ConsoleOutContainer(void *c,int len);

#endif
