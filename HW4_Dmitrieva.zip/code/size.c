#include <stdio.h>
#include "extdata.h"

int getTwoDimSize(void *td) {
	int size=*((int*)td);
	return size*size+1;
}

int getDiagonalSize(void *d) {
	int size=*((int*)d);
	return size+1;
}

int getLowerSize(void *l) {
	int size=*((int*)l);
	int len=(size+1)*(size/2)+(1+size/2)*(size%2);
	return len+1;
}

int getSize(void *m) {
	int key=*((int*)m);
	if (key==TWODIM) {
		int size=getTwoDimSize(m+intSize);
		return size;
	} else if (key==DIAGONAL) {
		int size=getDiagonalSize(m+intSize);
		return size;
	} else if (key==LOWER) {
		int size=getLowerSize(m+intSize);
		return size;
	} else {
		return 0;
	}
}

