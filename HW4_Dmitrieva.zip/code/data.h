#ifndef __data__
#define __data__

int const intSize=sizeof(int);
int const maxSize=1000*(20*20+1)*intSize;
int const TWODIM=1;
int const DIAGONAL=2;
int const LOWER=3;

void InContainer(void *c, int *len, FILE *ifst);
void InRndContainer(void *c, int *len, int size);
void OutContainer(void *c,int len,FILE *ofst);
extern double MatrixAverage(void *m, int length,int size);
int getSize(void *m);
void Sort(void *cont,int len, FILE *ofst);

#endif

