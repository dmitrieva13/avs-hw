#include <stdlib.h>
#include <stdio.h>
#include "extdata.h"

int Random() {
	return rand()%1000+1;
}

int InRndTwoDim(void *td) {
	int size=Random()%20+1;
	*((int*)td)=size;
	for (int i=0;i<size*size;++i){
		int value=Random();
		*((int*)(td+intSize*(i+1)))=value;
	}
	return size*size+1;
}

int InRndDiagonal(void *d) {
	int size=Random()%20+1;
	*((int*)d)=size;
	for (int i=0;i<size;++i){
		int value=Random();
		*((int*)(d+intSize*(i+1)))=value;
	}
	return size+1;
}

int InRndLower(void *l) {
	int size=Random()%20+1;
	*((int*)l)=size;
	int length=(size+1)*(size/2)+(1+size/2)*(size%2);
	for (int i=0;i<length;++i){
		int value=Random();
		*((int*)(l+intSize*(i+1)))=value;
	}
	return length+1;
}

int InRndMatrix(void *m) {
	int key=1+rand()%3;
	int len;
	switch (key) {
		case 1:
			*((int*)m)=TWODIM;
			len=InRndTwoDim(m+intSize);
			return len+1;
		case 2:
			*((int*)m)=DIAGONAL;
			len=InRndDiagonal(m+intSize);
			return len+1;
		case 3:
			*((int*)m)=LOWER;
			len=InRndLower(m+intSize);
			return len+1;
		default:
			return 0;
	}
}

void InRndContainer(void *c, int *len, int size) {
	void *tmp=c;
	while (*len<size) {
		int sz=InRndMatrix(tmp);
	      	if (sz>0) {
			tmp=tmp+sz*intSize;
			(*len)++;
		}
	}
	ConsoleOutContainer(c,*len);
}
