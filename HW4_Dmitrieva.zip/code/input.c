#include <stdio.h>
#include "extdata.h"

int InTwoDim(void *td,FILE *ifst) {
	int size;
	fscanf(ifst,"%d ", &size);
	*((int*)td)=size;
	for (int i=0;i<size*size;++i) {
		int val;
		fscanf(ifst,"%d ",&val);
		*((int*)(td+intSize*(i+1)))=val;
	}
	return size*size+1;
}

int InDiagonal(void *d,FILE *ifst) {
	fscanf(ifst,"%d ", (int*)d);
	int size=*((int*)d);
	for (int i=0;i<size;++i) {
		fscanf(ifst,"%d ",(int*)(d+intSize*(i+1)));
	}
	return size+1;
}

int InLower(void *l,FILE *ifst) {
	fscanf(ifst,"%d ", (int*)l);
	int size=*((int*)l);
	int len=(size+1)*(size/2)+(1+size/2)*(size%2);
	for (int i=0;i<len;++i) {
		fscanf(ifst,"%d ",(int*)(l+intSize*(i+1)));
	}
	return len+1;
}

int InMatrix(void *m, int key,FILE *ifst) {
	int len;
	switch (key) {
		case 1:
			*((int*)m)=TWODIM;
			len=InTwoDim(m+intSize,ifst);
			return len+1;
		case 2:
			*((int*)m)=DIAGONAL;
			len=InDiagonal(m+intSize,ifst);
			return len+1;
		case 3:
			*((int*)m)=LOWER;
			len=InLower(m+intSize,ifst);
			return len+1;
		default:
			return 0;
	}
}

void InContainer(void *c,int *len,FILE *ifst) {
	void *tmp=c;
	int key;
	while (fscanf(ifst,"%d ",&key)!=EOF) {
		int size=InMatrix(tmp,key,ifst);
		if (size>0) {
			tmp=tmp+size*intSize;
			(*len)++;
		}
	}
	ConsoleOutContainer(c,*len);
}
