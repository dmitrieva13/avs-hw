#ifndef MATRIX_H
#define MATRIX_H

#include "diag.h"
#include "twodim.h"
#include "lower.h"

struct Matrix {
	enum MatrixType {
	TWO_DIMENSIONAL,
	DIAGONAL,
	LOWER_TRIANGLE
	};
	MatrixType key;
	union {
		TwoDim t;
		Diagonal d;
		Lower l;
	};
};

// Matrix input from file.
Matrix *Input(ifstream &ifst);

// Create random matrix.
Matrix *RandomInput();

// Output matrix.
void Out(Matrix *m, ofstream &ofst);

// Counting average value of matrix.
double Median(Matrix &m);

#endif
