#include "matrix.h"

Matrix *Input(ifstream &ifst) {
	Matrix *m;
	int k;
	ifst>>k;
	switch (k) {
		case 1:
			m=new Matrix;
			m->key=Matrix::TWO_DIMENSIONAL;
			Input(m->t,ifst);
			return m;
		case 2:
			m=new Matrix;
			m->key=Matrix::DIAGONAL;
			Input(m->d,ifst);
			return m;	
		case 3:
			m=new Matrix;
			m->key=Matrix::LOWER_TRIANGLE;
			Input(m->l,ifst);
			return m;
		default:
			return 0;
	}
}

Matrix *RandomInput() {
	Matrix *m;
	auto k=rand()%3+1;
	switch (k) {
		case 1:
			m=new Matrix;
			m->key=Matrix::TWO_DIMENSIONAL;
			RandomInput(m->t);
			return m;
		case 2:
			m=new Matrix;
			m->key=Matrix::DIAGONAL;
			RandomInput(m->d);
			return m;	
		case 3:
			m=new Matrix;
			m->key=Matrix::LOWER_TRIANGLE;
			RandomInput(m->l);
			return m;
		default:
			return 0;
	}
}

void Out(Matrix *m, ofstream &ofst) {
	switch (m->key) {
		case Matrix::TWO_DIMENSIONAL:
			Out(m->t,ofst);
			break;
		case Matrix::DIAGONAL:
			Out(m->d,ofst);
			break;
		case Matrix::LOWER_TRIANGLE:
			Out(m->l,ofst);
			break;
		default:
			ofst << "Incorrect matrix type!\n";
	}
}

double Median(Matrix &m) {
	switch (m.key) {
		case Matrix::TWO_DIMENSIONAL:
			return Median(m.t);
			
		case Matrix::DIAGONAL:
			return Median(m.d);
			
		case Matrix::LOWER_TRIANGLE:
			return Median(m.l);
			
		default:
			return 0.0;
	}
}

