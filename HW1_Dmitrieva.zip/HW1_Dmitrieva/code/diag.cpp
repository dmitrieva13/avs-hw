#include "diag.h"

void Input(Diagonal& dm, ifstream &ifst) {
	ifst >> dm.size;
	dm.arr=new int[dm.size] {};
	for (int i=0;i<dm.size;++i) {
		ifst >> dm.arr[i];
	}
}

void RandomInput(Diagonal& dm) {
	dm.size=Random() % 20 +1;
	dm.arr=new int[dm.size] {};
	for (int i=0; i< dm.size; ++i) {
		dm.arr[i] = Random();
	}
}

void Out(Diagonal& dm, ofstream& ofst) {
	ofst << "This is diagonal matrix with size " << dm.size << "\n";
	for (int i=0; i<dm.size; ++i) {
		for (int j=0; j < dm.size; ++j) {
			if (i==j) {
			ofst << dm.arr[i] << " ";
			} else {
				ofst << "0 ";
			}
		}
		ofst << "\n";
	}
	ofst << "Median = " << Median(dm) << "\n\n";
}

double Median(Diagonal& dm) {
	int count=dm.size*dm.size;
	double sum=0;
	for (int i=0; i<dm.size;++i) {
		sum+=dm.arr[i];
	}
	return sum/count;
}
