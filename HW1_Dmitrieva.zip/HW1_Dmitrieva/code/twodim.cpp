#include "twodim.h"

void Input(TwoDim& td, ifstream &ifst) {
	ifst >> td.size;
	td.arr=new int[td.size*td.size] {};	
	int count=0;
	for (int i=0;i<td.size*td.size;++i) {
		ifst >> td.arr[i];
			++count;
	}
}


void RandomInput(TwoDim& td) {
	td.size=Random() % 20 +1;
	td.arr=new int[td.size*td.size];
	for (int i=0;i<td.size*td.size;++i) {
		td.arr[i]=Random();
	}
}

void Out(TwoDim& td, ofstream& ofst) {
	ofst << "This is two-dimensional matrix with size " << td.size << "\n";
	for (int i=0; i<td.size*td.size; ++i) {
		ofst << td.arr[i] << " ";
		if ((i+1)%td.size==0) {
			ofst << "\n";
		}
	}
	ofst << "Median = " << Median(td) << "\n\n";
}

double Median(TwoDim& td) {
	int count=td.size*td.size;
	double sum=0;
	for (int i=0; i<td.size*td.size;++i) {
		sum+=td.arr[i];
	}
	return sum/count;
}
