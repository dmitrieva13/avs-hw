#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "container.h"


int main() {
	Container cnt;
	Init(cnt);
	printf("Please enter \"f\" to use data from files.\nEnter \"r\" to create random matrices.\nYou enter: ");
	char c;
	scanf(" %c",&c);
	switch (c) {
		case 'f': {
				  for (int i=0;i<6;++i) {
					char num='1'+i;
					char tmplte[16]={'T','e','s','t','s','/','t','e','s','t','_',num,'.','t','x','t'};				
					ifstream ifst(tmplte);	
					Input(cnt,ifst);				}
			break;
			  }
		case 'r': {
			int len;
			printf("Please enter how many matrices you want to create (from 1 to 1000): ");
			scanf(" %d",&len);
			if (len < 1 || len > 1000) {
				printf("Incorrect number of matrices! It must be from 1 to 1000.\n");
				return 1;
			}
			srand(static_cast<unsigned int>(time(0)));
			RandomInput(cnt,len);
			break;
			  }
		default:
			printf("Incorrect operation!\n");
			return 2;
	}

	// Output result of first part of task.
	ofstream ofst1;
	ofst1.open("out1.txt");
	ofst1<<"Filled container:\n";
	Out(cnt,ofst1);
	ofst1.close();

	// Second part of task.
	ofstream ofst2;
	ofst2.open("out2.txt");
	ofst2<<"Sorted container:\n";
	Sort(cnt,ofst2);
	ofst2.close();

	Clear(cnt);
	printf("Stop\n");

	return 0;
}
