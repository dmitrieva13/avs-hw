#ifndef CONTAINER_H
#define CONTAINER_H

#include "matrix.h"

struct Container {
	enum { maxLen=1000};
	int length;
	Matrix *cont[maxLen];
};

// Initialization.
void Init(Container &c);

// Clear the container.
void Clear(Container &c);

// Input data from file.
void Input(Container &c, ifstream &ifst);

// Create random container.
void RandomInput(Container &c, int size);

// Output container.
void Out(Container &c, ofstream &ofst);

// Binary Insertion sort - 2nd part of task.
void Sort(Container &c, ofstream &ofst);

#endif
