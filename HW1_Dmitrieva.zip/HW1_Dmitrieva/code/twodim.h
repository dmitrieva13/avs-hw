#ifndef TWODIM_H
#define TWODIM_H

#include <fstream>
#include "rnd.h"

using namespace std;

struct TwoDim {
	int size;
	int* arr;
};

// Input matrix from file.
void Input(TwoDim& td, ifstream &ifst);

// Create random matrix.
void RandomInput(TwoDim& td);

// Output matrix.
void Out(TwoDim& td, ofstream& ofst);

// Counting average value of matrix.
double Median(TwoDim& td);

#endif

