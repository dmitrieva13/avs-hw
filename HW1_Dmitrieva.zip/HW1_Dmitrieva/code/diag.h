#ifndef DIAG_H
#define DIAG_H

#include <stdio.h>
#include <fstream>
#include "rnd.h"

using namespace std;

struct Diagonal {
	int size;
	int* arr;
};

// Input diagonal matrix from file.
void Input(Diagonal& dm, ifstream &ifst);

// Create random diagonal matrix.
void RandomInput(Diagonal& dm);

// Output diagonal matrix.
void Out(Diagonal& dm, ofstream& ofst);

// Counting average value of matrix.
double Median(Diagonal& dm);

#endif

