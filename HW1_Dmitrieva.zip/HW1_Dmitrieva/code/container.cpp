#include "container.h"

void Init(Container &c) {
	c.length=0;
}

void Clear(Container &c) {
	for (int i=0;i<c.length;++i) {
		delete c.cont[i];
	}
	c.length=0;
}

void Input(Container &c, ifstream &ifst) {
	while (!ifst.eof()) {
		c.cont[c.length]=Input(ifst);
		if (c.cont[c.length]!=nullptr) {
			++c.length;
			printf("Matrix ");
			printf("%d",c.length);
			printf(" was entered.\n");
		}	}
} 

void RandomInput(Container &c, int size) {
	while (c.length<size) {
		c.cont[c.length]=RandomInput();
		if (c.cont[c.length]!=nullptr) {
		 ++c.length;
		}
	}
}

void Out(Container &c, ofstream &ofst) {
	ofst << "Container contains " << c.length << " elements.\n";
	for (int i=0;i<c.length;++i) {
		ofst<<i+1<<": ";
		Out(c.cont[i],ofst);
	}
}

void Sort(Container &c, ofstream &ofst) {
	int i,j,top,bottom,mid,hop;
	Matrix* temp;
	for (i=1;i<c.length;++i) {
		temp=c.cont[i];
		top=i;
		bottom=0;
		hop=1;
		do {
			mid=top-hop;
			hop<<=1;
			if (Median(*temp)<Median(*c.cont[mid])) {
				top=mid;
			} else {
				bottom=mid+1;
			}
		} while (bottom+hop<=top);

		while (bottom!=top) {
			mid=(top+bottom)/2;
			if (Median(*temp)<Median(*c.cont[mid])) {
				top=mid;
			} else {
				bottom=mid+1;
			}
		}
		for (j=i;j>bottom;--j) {
			c.cont[j]=c.cont[j-1];
		}
		c.cont[j]=temp;
	}
	Out(c,ofst);
}
