#include "lower.h"

void Input(Lower& l, ifstream &ifst) {
	ifst >> l.size;
	l.arr=new int[(l.size+1)*(l.size/2)+(1+l.size/2)*(l.size%2)];
	int length=1;
	int currentInput=0;
	while (length<=l.size) {
		for (int i=0;i<length;++i) {
			ifst >> l.arr[currentInput];
			++currentInput;
		}
		++length;
	}
}

void RandomInput(Lower& l) {
	l.size=Random()%20+1;
	l.arr=new int[(l.size+1)*(l.size/2)+(1+l.size/2)*(l.size%2)];
	int current=0;
	for (int length=1;length<=l.size;++length) {
		for (int i=0;i<length;++i) {
			l.arr[current]=Random();
			++current;
		}
	}
}

void Out(Lower& l, ofstream& ofst) {
	ofst << "This is lower-triangle matrix with size " << l.size << "\n";
	int row=0,col=0;
	int current=0;
	for (int i=0;i<l.size;++i) {
		for (int j=0;j<l.size;++j) {
			if (i>=j) {
				ofst << l.arr[current] << " ";
				++current;
			} else {
				ofst << "0 ";
			}
		}
		ofst << "\n";
	}
	ofst << "Median = " << Median(l) << "\n\n";
}

double Median(Lower& l) {
	int count=l.size*l.size;
	int current=0;
	double sum=0.0;
	for (int i=0;i<l.size;++i) {
		for (int j=0;j<=i;++j) {
			sum+=l.arr[current];
			++current;
		}
	}
	return sum/count;
}
