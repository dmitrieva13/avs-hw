#ifndef RND_H
#define RND_H

#include <stdlib.h>

// Returns random number.
inline auto Random() {
	return rand() % 10000 + 1;
}

#endif
