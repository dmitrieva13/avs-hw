#ifndef LOWER_H
#define LOWER_H

#include <fstream>
#include "rnd.h"

using namespace std;

struct Lower {
	int size;
	int* arr;
};

// Input matrix from file.
void Input(Lower& l, ifstream &ifst);

// Create random lower-triangle matrix.
void RandomInput(Lower& l);

// Output matrix.
void Out(Lower& l, ofstream& ofst);

// Counting average value of matrix.
double Median(Lower& l);

#endif
